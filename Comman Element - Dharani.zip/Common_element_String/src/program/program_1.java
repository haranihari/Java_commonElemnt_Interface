package program;

public class program_1 {
	void program()
	{
	 int[] arr1 = {1, 2, 3, 4, 5};
     int[] arr2 = {0, 4, 8, 6, 7};
     System.out.println("The common elements in the array is:");
     
     for (int i = 0; i < arr1.length; i++) 
     {
         for (int j = 0; j < arr2.length; j++) 
         {
             if (arr1[i] == arr2[j]) 
             {
                 System.out.println(arr1[i]);
                 break;
             }
         }
     }
 }


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		program_1 obj = new program_1();
		obj.program();

	}

}

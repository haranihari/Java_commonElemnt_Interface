package sunday;

public interface dominos_interface_2 {
	void management();
	void foodconcept();
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

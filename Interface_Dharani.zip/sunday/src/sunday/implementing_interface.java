package sunday;

public class implementing_interface implements kfc_interface_1,dominos_interface_2{
	void contract1()
	{
		System.out.println("KFC Franchise details");
	}
	
void contract2() {
	System.out.println(" DOMINOS Franchise details");
}
	public void foodconcept() {
		System.out.println("follow recipes to attain our taste");
	
	}

	public void ambience() {
		System.out.println("follow exact instructions to attain good ambience");
	
	}
	public void management()
	{
		System.out.println("Follow all the rules and regulation in management details");
	}
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// For KFC
		implementing_interface dk = new implementing_interface();
		dk.contract1();
		dk.foodconcept();
		dk.ambience();
		// For DOMINOS
		dk.contract2();
		dk.foodconcept();
		dk.management();
		
		
		

	}


	

}

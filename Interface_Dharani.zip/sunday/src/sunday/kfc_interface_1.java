package sunday;

public interface  kfc_interface_1 {

	void foodconcept();
	void ambience();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
